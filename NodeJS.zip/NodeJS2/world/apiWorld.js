var config = require("../config");
var pgp = require("pg-promise")();
var db = pgp(config.getDbConnectionString());
module.exports = function (app) {
    //a. näidata kõiki riike 
 app.get("/api/country", function (req, res) {
 db.any("SELECT country.name FROM country ")
 .then(function (data) {
 res.json({
 status: "success",
 data: data,
 });
 })
 .catch((err) => {
 res.json({
 description: "Can’t find any room",
 error: err,
 });
 });
 });

// näidata kõiki määratud mandri riike (riigi nimi, pealinn) 
app.get("/api/continent/:continent/country", function (req, res) {
    db.any("SELECT country.name AS country,city.name AS capital FROM country JOIN city ON country.capital = city.id where country.continent='" + req.params.continent + "'")
    .then(function (data) {
    res.json({
    status: "success",
    data: data,
    });
    })
    .catch((err) => {
    res.json({
    description: "Can’t find any room",
    error: err,
    });
    });
    });
    //näidata täielikku teavet määratud linna kohta (2 GET - päringut: linnakoodi ja nime järgi) 
    app.get("/api/name/:name/countrycode", function (req, res) {
        db.any("SELECT city.countrycode,city.name,city.id FROM city where city.name='" + req.params.name + "'")
        .then(function (data) {
        res.json({
        status: "success",
        data: data,
        });
        })
        .catch((err) => {
        res.json({
        description: "Can’t find any room",
        error: err,
        });
        });
        });  
        //näidata täielikku teavet määratud linna kohta (2 GET - päringut: linnakoodi ja nime järgi) 
    app.get("/api/code/:code/name", function (req, res) {
        db.any("SELECT city.countrycode,city.name,city.id FROM city where city.countrycode='" + req.params.code + "'")
        .then(function (data) {
        res.json({
        status: "success",
        data: data,
        });
        })
        .catch((err) => {
        res.json({
        description: "Can’t find any room",
        error: err,
        });
        });
        });  
        //näidata täielikku teavet määratud riigi kohta (teave riigi ja linnade kohta). Andmete lugemiseks looge ka 2 päringut: riigi koodi ja nime järgi.
    app.get("/api/code/:code/country", function (req, res) {
        db.any("SELECT country.name AS country,city.name AS capital,continent,code,city.countrycode AS code FROM country JOIN city ON country.capital = city.id where code='" + req.params.code + "'" )
            .then(function (data) {
                res.json({
                    status: "success",
                    data: data,
                });
            })
            .catch((err) => {
                res.json({
                    description: "Can’t find any room",
                    error: err,
            });
            });
            });  
            app.get("/api/name/:name/country", function (req, res) {
                db.any("SELECT country.name AS country,city.name AS capital,continent,code,city.countrycode AS code FROM country JOIN city ON country.capital = city.id where country.name='" + req.params.name + "'" )
                    .then(function (data) {
                        res.json({
                            status: "success",
                            data: data,
                        });
                    })
                    .catch((err) => {
                        res.json({
                            description: "Can’t find any room",
                            error: err,
                    });
                    });
                    });  

};
