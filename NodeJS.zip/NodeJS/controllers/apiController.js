var config = require("../config");
var pgp = require("pg-promise")();
var db = pgp(config.getDbConnectionString());
module.exports = function (app) {
//Näidata, millised andurid on konkreetse kontrolleriga ühendatud
    app.get("/api/id_controller/:control/sensors", function (req, res) {
        db.any("SELECT sensor.sensorname FROM controller JOIN controller_sensor ON controller.id = controller_sensor.id_controller JOIN sensor " +
        "ON sensor.id = controller_sensor.id_sensor where controller.controllername='" + req.params.control + "'"
        )
            .then(function (data) {
                res.json({
                    status: "success",
                    data: data,
                });
            })
            .catch((err) => {
                res.json({
                    description: "Can’t find any room",
                    error: err,
                });
            });
    });

//Näidata, millised kontrollerid on andmebaasis
    app.get("/api/controller", function (req, res) {
        db.any("SELECT controller.controllername FROM controller "
        )
            .then(function (data) {
                res.json({
                    status: "success",
                    data: data,
                });
            })
            .catch((err) => {
                res.json({
                    description: "Can’t find any room",
                    error: err,
                });
            });
    }); 

    //Päring: Millised auditooriumide numbrid on andmebaasis?
    app.get("/api/rooms", function (req, res) {
        db.any("SELECT DISTINCT room FROM controller_sensor")
        .then(function (data) {
        res.json({
        status: "success",
        data: data,
        });
        })
        .catch((err) => {
        res.json({
        description: "Can’t find any room",
        error: err,
        });
        });
        });

        //Päring: Millised andurid on auditooriumis nr ...
        app.get("/api/room/:number/sensors", function (req, res) {
            db.any(
           "SELECT sensor.sensorname FROM sensor INNER JOIN controller_sensor ON controller_sensor.id_sensor=sensor.id " +
            "WHERE controller_sensor.room=" + req.params.number + ":: varchar"
            )
            .then(function (data) {
            res.json({
            status: "success",
            data: data,
            });
            })
            .catch(function (err) {
            return next(err);
            });
            });
};
